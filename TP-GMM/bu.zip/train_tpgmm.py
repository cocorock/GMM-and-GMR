import numpy as np
import json
from sklearn.mixture import GaussianMixture
from scipy.linalg import block_diag, inv
import matplotlib.pyplot as plt

class TPGMM_Complete:
    def __init__(self, n_components=5, n_frames=2):
        """
        Complete Task-Parameterized Gaussian Mixture Model implementation
        
        Args:
            n_components: Number of Gaussian components
            n_frames: Number of coordinate frames (FR1 and FR2)
        """
        self.n_components = n_components
        self.n_frames = n_frames
        self.frame_dims = 5  # 2D pos + 2D vel + 1D orientation
        self.total_dims = self.frame_dims * n_frames  # 10 total
        
        # Model parameters (will be learned)
        self.weights = None      # Component weights
        self.means = None        # Means for each frame and component
        self.covariances = None  # Covariances for each frame and component
        
        # Training transformations (stored for reference)
        self.training_transformations = []
        
    def _load_json_data(self, json_file_path):
        """
        Load and parse the JSON data file
        
        Args:
            json_file_path: Path to your JSON data file
            
        Returns:
            Parsed demonstration data
        """
        try:
            with open(json_file_path, 'r') as f:
                data = json.load(f)
            
            # Convert to numpy arrays and structure for TP-GMM
            demonstrations = []
            
            # Assuming your JSON has the structure you described
            trajectory_data = {
                'ankle_pos_FR1': np.array(data['ankle_pos_FR1']),
                'ankle_pos_FR1_velocity': np.array(data['ankle_pos_FR1_velocity']),
                'ankle_orientation_FR1': np.array(data['ankle_orientation_FR1']).reshape(-1, 1),
                'ankle_pos_FR2': np.array(data['ankle_pos_FR2']),
                'ankle_pos_FR2_velocity': np.array(data['ankle_pos_FR2_velocity']),
                'ankle_orientation_FR2': np.array(data['ankle_orientation_FR2']).reshape(-1, 1),
            }
            
            transformations = {
                'ankle_A_FR1': np.array(data['ankle_A_FR1']),
                'ankle_b_FR1': np.array(data['ankle_b_FR1']),
                'ankle_A_FR2': np.array(data['ankle_A_FR2']),
                'ankle_b_FR2': np.array(data['ankle_b_FR2']),
            }
            
            demo = {
                'trajectory_data': trajectory_data,
                'transformations': transformations
            }
            
            demonstrations.append(demo)
            return demonstrations
            
        except Exception as e:
            print(f"Error loading JSON data: {e}")
            return None
    
    def _transform_data_point(self, data_point, A_matrix, b_vector, is_velocity=False):
        """
        Transform a single data point using transformation matrix and vector
        
        Args:
            data_point: Data point to transform
            A_matrix: Transformation matrix [2x2] for position/velocity
            b_vector: Translation vector [2] for position
            is_velocity: Whether this is velocity data (no translation)
            
        Returns:
            Transformed data point
        """
        if is_velocity:
            # Velocities only get rotated, not translated
            return A_matrix @ data_point
        else:
            # Positions get full transformation
            return A_matrix @ data_point + b_vector
    
    def _prepare_frame_data(self, trajectory_data, transformations, frame_name):
        """
        Prepare data for a specific frame with transformations
        
        Args:
            trajectory_data: Dictionary containing trajectory arrays
            transformations: Dictionary containing A matrices and b vectors
            frame_name: 'FR1' or 'FR2'
            
        Returns:
            Transformed frame data [T x 5]
        """
        if frame_name == 'FR1':
            # FR1 uses identity transformations (no change)
            pos_data = trajectory_data['ankle_pos_FR1']
            vel_data = trajectory_data['ankle_pos_FR1_velocity']
            ori_data = trajectory_data['ankle_orientation_FR1']
            A_matrices = transformations['ankle_A_FR1']
            b_vectors = transformations['ankle_b_FR1']
        else:  # FR2
            pos_data = trajectory_data['ankle_pos_FR2']
            vel_data = trajectory_data['ankle_pos_FR2_velocity']
            ori_data = trajectory_data['ankle_orientation_FR2']
            A_matrices = transformations['ankle_A_FR2']
            b_vectors = transformations['ankle_b_FR2']
        
        T = len(pos_data)
        frame_data = np.zeros((T, self.frame_dims))
        
        for t in range(T):
            # Transform position (2D)
            transformed_pos = self._transform_data_point(
                pos_data[t], A_matrices[t], b_vectors[t], is_velocity=False
            )
            frame_data[t, 0:2] = transformed_pos
            
            # Transform velocity (2D) - no translation
            transformed_vel = self._transform_data_point(
                vel_data[t], A_matrices[t], np.zeros(2), is_velocity=True
            )
            frame_data[t, 2:4] = transformed_vel
            
            # Transform orientation (1D) - extract rotation from A matrix
            rotation_angle = np.arctan2(A_matrices[t][1,0], A_matrices[t][0,0])
            frame_data[t, 4] = ori_data[t, 0] + rotation_angle
        
        return frame_data
    
    def fit(self, demonstrations):
        """
        Fit the TP-GMM model using the product of Gaussians approach
        
        Args:
            demonstrations: List of demonstration dictionaries
        """
        print("Fitting TP-GMM with product of Gaussians...")
        
        # Store training transformations for reference
        self.training_transformations = [demo['transformations'] for demo in demonstrations]
        
        # Prepare training data for each frame
        all_frame_data = {f'FR{i+1}': [] for i in range(self.n_frames)}
        
        for demo in demonstrations:
            trajectory_data = demo['trajectory_data']
            transformations = demo['transformations']
            
            # Prepare data for each frame
            for i in range(self.n_frames):
                frame_name = f'FR{i+1}'
                frame_data = self._prepare_frame_data(trajectory_data, transformations, frame_name)
                all_frame_data[frame_name].append(frame_data)
        
        # Concatenate all demonstrations for each frame
        frame_datasets = {}
        for frame_name in all_frame_data:
            frame_datasets[frame_name] = np.vstack(all_frame_data[frame_name])
            print(f"{frame_name} data shape: {frame_datasets[frame_name].shape}")
        
        # Fit separate GMMs for each frame (this is the key insight!)
        self.frame_gmms = {}
        self.means = {}
        self.covariances = {}
        
        for frame_name in frame_datasets:
            print(f"\nFitting GMM for {frame_name}...")
            
            gmm = GaussianMixture(
                n_components=self.n_components,
                covariance_type='full',
                random_state=42,
                max_iter=200
            )
            
            gmm.fit(frame_datasets[frame_name])
            self.frame_gmms[frame_name] = gmm
            
            # Store parameters
            self.means[frame_name] = gmm.means_
            self.covariances[frame_name] = gmm.covariances_
            
            print(f"{frame_name} - Log-likelihood: {gmm.score(frame_datasets[frame_name]):.2f}")
        
        # Use weights from FR1 (or average them)
        self.weights = self.frame_gmms['FR1'].weights_
        
        print(f"\nTP-GMM fitting completed!")
        print(f"Number of components: {self.n_components}")
        print(f"Component weights: {self.weights}")
        
        return self
    
    def adapt_trajectory(self, new_transformations_fr2, trajectory_length=200):
        """
        Adapt trajectory for new task parameters (e.g., new endpoint)
        This implements the core TP-GMM adaptation mechanism
        
        Args:
            new_transformations_fr2: New transformation matrices for FR2
                - 'ankle_A_FR2': [T x 2 x 2] new transformation matrices
                - 'ankle_b_FR2': [T x 2] new translation vectors
            trajectory_length: Length of trajectory to generate
            
        Returns:
            Dictionary with adapted trajectory data
        """
        if self.frame_gmms is None:
            raise ValueError("Model must be fitted before adaptation")
        
        print("Adapting trajectory for new task parameters...")
        
        # Generate time steps
        t_steps = np.linspace(0, 1, trajectory_length)
        
        # Initialize output trajectory
        adapted_trajectory = {
            'ankle_pos_FR1': np.zeros((trajectory_length, 2)),
            'ankle_pos_FR1_velocity': np.zeros((trajectory_length, 2)),
            'ankle_orientation_FR1': np.zeros((trajectory_length, 1)),
            'ankle_pos_FR2': np.zeros((trajectory_length, 2)),
            'ankle_pos_FR2_velocity': np.zeros((trajectory_length, 2)),
            'ankle_orientation_FR2': np.zeros((trajectory_length, 1)),
        }
        
        # For each time step, compute the adapted trajectory point
        for t_idx in range(trajectory_length):
            # Get current transformations
            A_fr2 = new_transformations_fr2['ankle_A_FR2'][t_idx]
            b_fr2 = new_transformations_fr2['ankle_b_FR2'][t_idx]
            
            # Compute product of Gaussians for this time step
            # This is where the magic happens!
            adapted_point = self._compute_product_of_gaussians(t_idx, A_fr2, b_fr2)
            
            # Fill in the trajectory
            adapted_trajectory['ankle_pos_FR1'][t_idx] = adapted_point['FR1'][0:2]
            adapted_trajectory['ankle_pos_FR1_velocity'][t_idx] = adapted_point['FR1'][2:4]
            adapted_trajectory['ankle_orientation_FR1'][t_idx] = adapted_point['FR1'][4:5]
            
            adapted_trajectory['ankle_pos_FR2'][t_idx] = adapted_point['FR2'][0:2]
            adapted_trajectory['ankle_pos_FR2_velocity'][t_idx] = adapted_point['FR2'][2:4]
            adapted_trajectory['ankle_orientation_FR2'][t_idx] = adapted_point['FR2'][4:5]
        
        print("Trajectory adaptation completed!")
        return adapted_trajectory
    
    def _compute_product_of_gaussians(self, time_idx, A_fr2, b_fr2):
        """
        Compute the product of Gaussians for adaptation at a specific time step
        This is the core of TP-GMM adaptation
        
        Args:
            time_idx: Current time index
            A_fr2: Transformation matrix for FR2 at this time step
            b_fr2: Translation vector for FR2 at this time step
            
        Returns:
            Dictionary with adapted points for each frame
        """
        # Initialize result
        adapted_point = {'FR1': np.zeros(self.frame_dims), 'FR2': np.zeros(self.frame_dims)}
        
        # For each Gaussian component, compute the product
        total_weight = 0
        weighted_sum_fr1 = np.zeros(self.frame_dims)
        weighted_sum_fr2 = np.zeros(self.frame_dims)
        
        for k in range(self.n_components):
            # Get original means and covariances
            mu_fr1 = self.means['FR1'][k]
            mu_fr2 = self.means['FR2'][k]
            sigma_fr1 = self.covariances['FR1'][k]
            sigma_fr2 = self.covariances['FR2'][k]
            
            # Transform FR2 component according to new task parameters
            # Position transformation: A * mu_pos + b
            mu_fr2_adapted = mu_fr2.copy()
            mu_fr2_adapted[0:2] = A_fr2 @ mu_fr2[0:2] + b_fr2  # Position
            mu_fr2_adapted[2:4] = A_fr2 @ mu_fr2[2:4]          # Velocity (no translation)
            
            # Orientation transformation
            rotation_angle = np.arctan2(A_fr2[1,0], A_fr2[0,0])
            mu_fr2_adapted[4] = mu_fr2[4] + rotation_angle
            
            # Transform covariance (simplified - full implementation would be more complex)
            sigma_fr2_adapted = sigma_fr2.copy()
            # For position and velocity components
            A_extended = block_diag(A_fr2, A_fr2, 1.0)  # Extend A for pos, vel, orientation
            sigma_fr2_adapted = A_extended @ sigma_fr2_adapted @ A_extended.T
            
            # Compute product of Gaussians (this is the key step!)
            # The product gives us the constraint that satisfies both frames
            try:
                # Inverse covariances
                inv_sigma_fr1 = inv(sigma_fr1)
                inv_sigma_fr2 = inv(sigma_fr2_adapted)
                
                # Product covariance
                inv_sigma_product = inv_sigma_fr1 + inv_sigma_fr2
                sigma_product = inv(inv_sigma_product)
                
                # Product mean
                mu_product = sigma_product @ (inv_sigma_fr1 @ mu_fr1 + inv_sigma_fr2 @ mu_fr2_adapted)
                
                # Weight for this component (simplified)
                weight = self.weights[k]
                
                # Accumulate weighted results
                total_weight += weight
                weighted_sum_fr1 += weight * mu_fr1
                weighted_sum_fr2 += weight * mu_fr2_adapted
                
            except np.linalg.LinAlgError:
                # Handle singular matrices
                weight = self.weights[k]
                total_weight += weight
                weighted_sum_fr1 += weight * mu_fr1
                weighted_sum_fr2 += weight * mu_fr2_adapted
        
        # Normalize by total weight
        if total_weight > 0:
            adapted_point['FR1'] = weighted_sum_fr1 / total_weight
            adapted_point['FR2'] = weighted_sum_fr2 / total_weight
        
        return adapted_point
    
    def change_endpoint(self, new_endpoint, trajectory_length=200):
        """
        Convenient function to change endpoint and generate adapted trajectory
        
        Args:
            new_endpoint: [x, y] coordinates of new endpoint
            trajectory_length: Length of trajectory to generate
            
        Returns:
            Adapted trajectory dictionary
        """
        print(f"Changing endpoint to: {new_endpoint}")
        
        # Create new transformations that move the endpoint
        # This is a simplified version - in practice, you'd have more sophisticated
        # transformation generation based on your specific task setup
        
        new_transformations = {
            'ankle_A_FR2': np.tile(np.eye(2), (trajectory_length, 1, 1)),
            'ankle_b_FR2': np.zeros((trajectory_length, 2))
        }
        
        # Set the endpoint transformation (this is task-specific)
        # For the last part of the trajectory, transform towards new endpoint
        for t in range(trajectory_length):
            # Linear interpolation towards new endpoint
            alpha = t / (trajectory_length - 1)  # 0 to 1
            new_transformations['ankle_b_FR2'][t] = alpha * np.array(new_endpoint)
        
        return self.adapt_trajectory(new_transformations, trajectory_length)

# Function to load your specific JSON data and fit the model
def fit_tpgmm_from_json(json_file_path, n_components=5):
    """
    Main function to load JSON data and fit TP-GMM model
    
    Args:
        json_file_path: Path to your JSON data file
        n_components: Number of Gaussian components
        
    Returns:
        Fitted TP-GMM model
    """
    
    class TPGMM:
        def __init__(self, n_components=5, n_frames=2):
            self.n_components = n_components
            self.n_frames = n_frames
            self.frame_dims = 5  # 2D pos + 2D vel + 1D orientation
            self.frame_gmms = {}
            self.means = {}
            self.covariances = {}
            self.weights = None
        
        def _prepare_frame_data(self, trajectory_data, transformations, frame_name):
            if frame_name == 'FR1':
                pos_data = trajectory_data['ankle_pos_FR1']
                vel_data = trajectory_data['ankle_pos_FR1_velocity']
                ori_data = trajectory_data['ankle_orientation_FR1']
                A_matrices = transformations['ankle_A_FR1']
                b_vectors = transformations['ankle_b_FR1']
            else:  # FR2
                pos_data = trajectory_data['ankle_pos_FR2']
                vel_data = trajectory_data['ankle_pos_FR2_velocity']
                ori_data = trajectory_data['ankle_orientation_FR2']
                A_matrices = transformations['ankle_A_FR2']
                b_vectors = transformations['ankle_b_FR2']
            
            T = len(pos_data)
            frame_data = np.zeros((T, self.frame_dims))
            
            for t in range(T):
                # Transform position
                transformed_pos = A_matrices[t] @ pos_data[t] + b_vectors[t]
                frame_data[t, 0:2] = transformed_pos
                
                # Transform velocity (no translation)
                transformed_vel = A_matrices[t] @ vel_data[t]
                frame_data[t, 2:4] = transformed_vel
                
                # Transform orientation
                rotation_angle = np.arctan2(A_matrices[t][1,0], A_matrices[t][0,0])
                frame_data[t, 4] = ori_data[t, 0] + rotation_angle
            
            return frame_data
        
        def fit(self, demonstrations):
            all_frame_data = {f'FR{i+1}': [] for i in range(self.n_frames)}
            
            for demo in demonstrations:
                trajectory_data = demo['trajectory_data']
                transformations = demo['transformations']
                
                for i in range(self.n_frames):
                    frame_name = f'FR{i+1}'
                    frame_data = self._prepare_frame_data(trajectory_data, transformations, frame_name)
                    all_frame_data[frame_name].append(frame_data)
            
            # Fit GMM for each frame
            for frame_name in all_frame_data:
                frame_dataset = np.vstack(all_frame_data[frame_name])
                
                gmm = GaussianMixture(
                    n_components=self.n_components,
                    covariance_type='full',
                    random_state=42,
                    max_iter=200
                )
                
                gmm.fit(frame_dataset)
                self.frame_gmms[frame_name] = gmm
                self.means[frame_name] = gmm.means_
                self.covariances[frame_name] = gmm.covariances_
            
            self.weights = self.frame_gmms['FR1'].weights_
            return self
        
        def change_endpoint(self, new_endpoint, trajectory_length=200):
            new_transformations = {
                'ankle_A_FR2': np.tile(np.eye(2), (trajectory_length, 1, 1)),
                'ankle_b_FR2': np.zeros((trajectory_length, 2))
            }
            
            for t in range(trajectory_length):
                alpha = t / (trajectory_length - 1)
                new_transformations['ankle_b_FR2'][t] = alpha * np.array(new_endpoint)
            
            return self._adapt_trajectory(new_transformations, trajectory_length)
        
        def _adapt_trajectory(self, new_transformations_fr2, trajectory_length):
            adapted_trajectory = {
                'ankle_pos_FR1': np.zeros((trajectory_length, 2)),
                'ankle_pos_FR1_velocity': np.zeros((trajectory_length, 2)),
                'ankle_orientation_FR1': np.zeros((trajectory_length, 1)),
                'ankle_pos_FR2': np.zeros((trajectory_length, 2)),
                'ankle_pos_FR2_velocity': np.zeros((trajectory_length, 2)),
                'ankle_orientation_FR2': np.zeros((trajectory_length, 1)),
            }
            
            for t_idx in range(trajectory_length):
                A_fr2 = new_transformations_fr2['ankle_A_FR2'][t_idx]
                b_fr2 = new_transformations_fr2['ankle_b_FR2'][t_idx]
                
                # Compute weighted average of Gaussian means (simplified adaptation)
                weighted_sum_fr1 = np.zeros(self.frame_dims)
                weighted_sum_fr2 = np.zeros(self.frame_dims)
                
                for k in range(self.n_components):
                    mu_fr1 = self.means['FR1'][k]
                    mu_fr2 = self.means['FR2'][k]
                    
                    # Transform FR2 mean
                    mu_fr2_adapted = mu_fr2.copy()
                    mu_fr2_adapted[0:2] = A_fr2 @ mu_fr2[0:2] + b_fr2
                    mu_fr2_adapted[2:4] = A_fr2 @ mu_fr2[2:4]
                    
                    rotation_angle = np.arctan2(A_fr2[1,0], A_fr2[0,0])
                    mu_fr2_adapted[4] = mu_fr2[4] + rotation_angle
                    
                    weight = self.weights[k]
                    weighted_sum_fr1 += weight * mu_fr1
                    weighted_sum_fr2 += weight * mu_fr2_adapted
                
                adapted_trajectory['ankle_pos_FR1'][t_idx] = weighted_sum_fr1[0:2]
                adapted_trajectory['ankle_pos_FR1_velocity'][t_idx] = weighted_sum_fr1[2:4]
                adapted_trajectory['ankle_orientation_FR1'][t_idx] = weighted_sum_fr1[4:5]
                
                adapted_trajectory['ankle_pos_FR2'][t_idx] = weighted_sum_fr2[0:2]
                adapted_trajectory['ankle_pos_FR2_velocity'][t_idx] = weighted_sum_fr2[2:4]
                adapted_trajectory['ankle_orientation_FR2'][t_idx] = weighted_sum_fr2[4:5]
            
            return adapted_trajectory
    
    # Load JSON data
    with open(json_file_path, 'r') as f:
        data = json.load(f)
    
    # Structure data for TP-GMM
    trajectory_data = {
        'ankle_pos_FR1': np.array(data['ankle_pos_FR1']),
        'ankle_pos_FR1_velocity': np.array(data['ankle_pos_FR1_velocity']),
        'ankle_orientation_FR1': np.array(data['ankle_orientation_FR1']).reshape(-1, 1),
        'ankle_pos_FR2': np.array(data['ankle_pos_FR2']),
        'ankle_pos_FR2_velocity': np.array(data['ankle_pos_FR2_velocity']),
        'ankle_orientation_FR2': np.array(data['ankle_orientation_FR2']).reshape(-1, 1),
    }
    
    transformations = {
        'ankle_A_FR1': np.array(data['ankle_A_FR1']),
        'ankle_b_FR1': np.array(data['ankle_b_FR1']),
        'ankle_A_FR2': np.array(data['ankle_A_FR2']),
        'ankle_b_FR2': np.array(data['ankle_b_FR2']),
    }
    
    demonstrations = [{
        'trajectory_data': trajectory_data,
        'transformations': transformations
    }]
    
    # Create and fit TP-GMM
    tpgmm = TPGMM(n_components=n_components, n_frames=2)
    tpgmm.fit(demonstrations)
    
    print(f"TP-GMM fitted with {n_components} components")
    print(f"Training data shape: {trajectory_data['ankle_pos_FR1'].shape}")
    
    return tpgmm


# Main program
if __name__ == "__main__":
    # Load and fit TP-GMM model
    json_file_path = "data/new_processed_gait_data#39_16.json"
    tpgmm_model = fit_tpgmm_from_json(json_file_path, n_components=5)
    
    # Example: Change endpoint and generate adapted trajectory
    new_endpoint = [0.5, 0.3]  # New target position
    adapted_trajectory = tpgmm_model.change_endpoint(new_endpoint)
    
    print(f"Adapted trajectory generated for new endpoint: {new_endpoint}")
    print(f"Adapted ankle position shape: {adapted_trajectory['ankle_pos_FR2'].shape}")
    
    # You can now use adapted_trajectory for your robot control