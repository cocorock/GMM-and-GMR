"""
Task-Parameterized Gaussian Mixture Model (TP-GMM) Implementation
================================================================

This implementation provides a complete TP-GMM system for gait trajectory learning
and adaptation using scikit-learn's GMM library.

Features:
- Handles 5D trajectory data per frame (2D position + 2D velocity + 1D orientation)
- Supports two coordinate frames (FR1: robot frame, FR2: task frame)
- Implements product of Gaussians for trajectory adaptation
- Endpoint adaptation for new target positions
- Supports multiple demonstrations from JSON array
- Saves model to .pkl and info to .txt

Author: Generated for gait trajectory learning
Date: 2025-07-15
"""

import json
import numpy as np
import pickle
from sklearn.mixture import GaussianMixture
from scipy.linalg import block_diag, inv
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')


class TPGMM:
    """
    Task-Parameterized Gaussian Mixture Model for trajectory learning and adaptation
    """

    def __init__(self, n_components=5, n_frames=2):
        """
        Initialize TP-GMM model

        Args:
            n_components: Number of Gaussian components
            n_frames: Number of coordinate frames (default: 2 for FR1 and FR2)
        """
        self.n_components = n_components
        self.n_frames = n_frames
        self.frame_dims = 5  # 2D pos + 2D vel + 1D orientation
        self.frame_gmms = {}
        self.means = {}
        self.covariances = {}
        self.weights = None
        self.training_data_shape = None

    def save_model(self, model_path):
        """
        Save the trained TP-GMM model to a .pkl file

        Args:
            model_path: Path to save the model file
        """
        with open(model_path, 'wb') as f:
            pickle.dump(self, f)
        print(f"Model saved to {model_path}")

    def save_info(self, info_path):
        """
        Save model information to a .txt file

        Args:
            info_path: Path to save the info file
        """
        info = self.get_model_info()
        with open(info_path, 'w') as f:
            for key, value in info.items():
                f.write(f"{key}: {value}")
        print(f"Model information saved to {info_path}")

    def get_model_info(self):
        """
        Get information about the fitted model

        Returns:
            Dictionary with model information
        """
        if self.frame_gmms is None:
            return {"status": "Model not fitted"}

        info = {
            "n_components": self.n_components,
            "n_frames": self.n_frames,
            "frame_dims": self.frame_dims,
            "training_data_shape": self.training_data_shape,
            "component_weights": self.weights.tolist(),
            "converged": {frame: self.frame_gmms[frame].converged_ for frame in self.frame_gmms.keys()},
            "log_likelihood": {frame: self.frame_gmms[frame].score(self.frame_datasets[frame]) 
                             for frame in self.frame_gmms.keys()}
        }

        return info


def fit_tpgmm_from_json(json_file_path, n_components=5, max_demonstrations=None):
    """
    Main function to load JSON data and fit TP-GMM model

    Args:
        json_file_path: Path to your JSON data file
        n_components: Number of Gaussian components
        max_demonstrations: Maximum number of demonstrations to use (None = use all)

    Returns:
        Fitted TP-GMM model
    """
    print(f"Loading data from: {json_file_path}")

    # Load JSON data
    try:
        with open(json_file_path, 'r') as f:
            data = json.load(f)
        print("JSON data loaded successfully!")
        print(f"Found {len(data)} demonstrations in the dataset")
    except FileNotFoundError:
        print(f"Error: File {json_file_path} not found!")
        return None
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in {json_file_path}")
        return None

    # Limit demonstrations if specified
    if max_demonstrations is not None and max_demonstrations < len(data):
        data = data[:max_demonstrations]
        print(f"Using first {max_demonstrations} demonstrations")

    # Process each demonstration
    demonstrations = []

    try:
        for demo_idx, demo_data in enumerate(data):
            print(f"Processing demonstration {demo_idx + 1}/{len(data)}...")

            # Structure trajectory data
            trajectory_data = {
                'ankle_pos_FR1': np.array(demo_data['ankle_pos_FR1']),
                'ankle_pos_FR1_velocity': np.array(demo_data['ankle_pos_FR1_velocity']),
                'ankle_orientation_FR1': np.array(demo_data['ankle_orientation_FR1']),
                'ankle_pos_FR2': np.array(demo_data['ankle_pos_FR2']),
                'ankle_pos_FR2_velocity': np.array(demo_data['ankle_pos_FR2_velocity']),
                'ankle_orientation_FR2': np.array(demo_data['ankle_orientation_FR2']),
            }

            # Structure transformation data
            transformations = {
                'ankle_A_FR1': np.array(demo_data['ankle_A_FR1']),
                'ankle_b_FR1': np.array(demo_data['ankle_b_FR1']),
                'ankle_A_FR2': np.array(demo_data['ankle_A_FR2']),
                'ankle_b_FR2': np.array(demo_data['ankle_b_FR2']),
            }

            # Validate data shapes
            expected_length = len(trajectory_data['ankle_pos_FR1'])
            print(f"  Trajectory length: {expected_length}")

            # Add to demonstrations list
            demonstrations.append({
                'trajectory_data': trajectory_data,
                'transformations': transformations,
                'demonstration_index': demo_data.get('demonstration_index', demo_idx)
            })

        print(f"Successfully processed {len(demonstrations)} demonstrations!")

    except KeyError as e:
        print(f"Error: Missing key in JSON data: {e}")
        return None
    except Exception as e:
        print(f"Error processing data: {e}")
        return None

    # Create and fit TP-GMM
    print(f"\nCreating TP-GMM with {n_components} components...")
    tpgmm = TPGMM(n_components=n_components, n_frames=2)
    tpgmm.fit(demonstrations)

    return tpgmm


def main():
    """
    Main program demonstrating TP-GMM usage
    """
    print("=" * 60)
    print("Task-Parameterized Gaussian Mixture Model (TP-GMM)")
    print("Gait Trajectory Learning and Adaptation")
    print("=" * 60)

    # Configuration
    json_file_path = "data/new_processed_gait_data#39_16.json"  # Update with your path
    n_components = 5
    max_demonstrations = 5  # Use first 5 demonstrations for faster training
    model_save_path = "tpgmm_model.pkl"
    info_save_path = "tpgmm_model_info.txt"

    # Load and fit TP-GMM model
    print("\n1. Loading and fitting TP-GMM model...")
    tpgmm_model = fit_tpgmm_from_json(
        json_file_path, 
        n_components=n_components,
        max_demonstrations=max_demonstrations
    )

    if tpgmm_model is None:
        print("Failed to load and fit model. Please check your data file.")
        return

    # Save the model and info
    print("\n2. Saving model and information...")
    tpgmm_model.save_model(model_save_path)
    tpgmm_model.save_info(info_save_path)

    # Example 1: Change endpoint and generate adapted trajectory
    print("\n3. Adapting trajectory for new endpoint...")
    new_endpoint = [0.5, 0.3]  # New target position [x, y]
    adapted_trajectory = tpgmm_model.change_endpoint(new_endpoint)

    print(f"   New endpoint: {new_endpoint}")
    print(f"   Adapted trajectory shape: {adapted_trajectory['ankle_pos_FR2'].shape}")

    # Example 2: Custom transformation matrices
    print("\n4. Example with custom transformations...")
    trajectory_length = 200
    custom_transformations = {
        'ankle_A_FR2': np.tile(np.eye(2), (trajectory_length, 1, 1)),
        'ankle_b_FR2': np.zeros((trajectory_length, 2))
    }

    # Create a curved path to new endpoint
    for t in range(trajectory_length):
        alpha = t / (trajectory_length - 1)
        # Curved trajectory towards [0.8, 0.2]
        custom_transformations['ankle_b_FR2'][t] = [
            0.8 * alpha,
            0.2 * alpha + 0.1 * np.sin(np.pi * alpha)  # Add curve
        ]

    curved_trajectory = tpgmm_model.adapt_trajectory(custom_transformations, trajectory_length)
    print(f"   Curved trajectory generated with shape: {curved_trajectory['ankle_pos_FR2'].shape}")

    # Optional: Plot trajectories (uncomment if you want to visualize)
    # print("\n5. Plotting trajectories...")
    # tpgmm_model.plot_trajectory(adapted_trajectory, "Adapted Trajectory", frame='FR2')
    # tpgmm_model.plot_trajectory(curved_trajectory, "Curved Trajectory", frame='FR2')

    print("\n" + "=" * 60)
    print("TP-GMM demonstration completed successfully!")
    print("You can now use the adapted trajectories for robot control.")
    print("=" * 60)


if __name__ == "__main__":
    main()
